(async () => {
  'use strict';
  const JF = window.JF;
  const { h, normalize } = JF;
  const $ = (s) => document.querySelector(s);
  const say = (m) => {
    const n = $('#msg');
    n.textContent = m;
    clearTimeout(say.t);
    say.t = setTimeout(() => { n.textContent = ''; }, 2500);
  };

  let entries = await JF.getEntries();
  const st = await chrome.storage.local.get(['enabled', 'disabledSites']);
  let enabled = st.enabled !== false;
  let disabledSites = Array.isArray(st.disabledSites) ? st.disabledSites : [];

  let host = '';
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const u = new URL(tab.url);
    if (/^https?:$/.test(u.protocol)) host = u.hostname;
  } catch (e) {}

  // ----- liga / desliga -----
  function syncToggles() {
    $('#on').checked = enabled;
    $('#onLabel').textContent = enabled ? 'Ligado' : 'Desligado';
    document.body.classList.toggle('off', !enabled);
    $('#siteName').textContent = host || '(esta página não é compatível)';
    $('#site').disabled = !host;
    $('#site').checked = host ? !disabledSites.includes(host) : false;
  }
  $('#on').onchange = async () => {
    enabled = $('#on').checked;
    await chrome.storage.local.set({ enabled });
    syncToggles();
  };
  $('#site').onchange = async () => {
    disabledSites = disabledSites.filter((x) => x !== host);
    if (!$('#site').checked) disabledSites.push(host);
    await chrome.storage.local.set({ disabledSites });
    syncToggles();
  };
  syncToggles();

  // ----- lista de dados -----
  function itemEl(e) {
    let timer;
    const save = (fn) => {
      clearTimeout(timer);
      timer = setTimeout(() => JF.updateEntries((es) => { const x = es.find((y) => y.id === e.id); if (x) fn(x); }), 150);
    };
    const multiline = e.multiline || (e.value || '').length > 80 || /\n/.test(e.value || '');
    const tag = h('span', { class: 'tag ' + (e.value ? 'ok' : 'empty') }, e.value ? 'preenchido' : 'vazio');
    const title = h('span', { class: 'title' }, e.label);
    const valCtl = h(multiline ? 'textarea' : 'input', Object.assign({
      class: 'txt', placeholder: 'Seu valor aqui', value: e.value || '',
      oninput: (ev) => {
        e.value = ev.target.value;
        tag.className = 'tag ' + (e.value ? 'ok' : 'empty');
        tag.textContent = e.value ? 'preenchido' : 'vazio';
        save((x) => { x.value = e.value; });
      }
    }, multiline ? { rows: 3 } : { type: 'text' }));
    const lab = h('input', {
      class: 'txt', type: 'text', value: e.label,
      onchange: (ev) => { e.label = ev.target.value.trim() || e.label; title.textContent = e.label; save((x) => { x.label = e.label; }); }
    });
    const ali = h('input', {
      class: 'txt', type: 'text', value: (e.aliases || []).join(', '), placeholder: 'nomes alternativos, separados por vírgula',
      onchange: (ev) => { e.aliases = ev.target.value.split(',').map((s) => s.trim()).filter(Boolean); save((x) => { x.aliases = e.aliases; }); }
    });
    const details = h('div', { class: 'details', hidden: true },
      h('small', {}, 'Nome do dado'), lab,
      h('small', {}, 'Como esse campo costuma aparecer nos formulários'), ali,
      h('button', {
        class: 'btn danger sm', type: 'button',
        onclick: async () => {
          await JF.updateEntries((es) => es.filter((x) => x.id !== e.id));
          entries = entries.filter((x) => x.id !== e.id);
          renderList();
        }
      }, 'Excluir este dado'));
    const more = h('button', { class: 'icon', type: 'button', title: 'Editar nome e apelidos', onclick: () => { details.hidden = !details.hidden; } }, '⋯');
    const el = h('div', { class: 'item' }, h('div', { class: 'top' }, title, tag, more), valCtl, details);
    el.dataset.s = normalize([e.label].concat(e.aliases || []).join(' '));
    return el;
  }

  function applyFilter() {
    const q = normalize($('#q').value);
    document.querySelectorAll('#list .item').forEach((n) => { n.hidden = !!q && !n.dataset.s.includes(q); });
  }
  function renderList() {
    $('#list').replaceChildren(...entries.map(itemEl));
    applyFilter();
  }
  $('#q').oninput = applyFilter;
  renderList();

  // ----- adicionar -----
  $('#add').onsubmit = async (ev) => {
    ev.preventDefault();
    const label = $('#nLabel').value.trim();
    if (!label) return;
    const extra = $('#nAliases').value.split(',').map((s) => s.trim()).filter(Boolean);
    const entry = { id: 'u' + Date.now().toString(36), label, value: $('#nValue').value, aliases: [label, ...extra], multiline: $('#nLong').checked };
    await JF.updateEntries((es) => { es.push(entry); });
    entries.push(entry);
    $('#add').reset();
    renderList();
    say('Adicionado ✓');
  };

  // ----- exportar / importar / restaurar -----
  $('#export').onclick = () => {
    const blob = new Blob([JSON.stringify(entries, null, 2)], { type: 'application/json' });
    const a = h('a', { href: URL.createObjectURL(blob), download: 'preenchedor-dados.json' });
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  };
  $('#import').onclick = () => $('#file').click();
  $('#file').onchange = async (ev) => {
    const f = ev.target.files[0];
    if (!f) return;
    try {
      const data = JSON.parse(await f.text());
      const incoming = (Array.isArray(data) ? data : []).filter((n) => n && typeof n.id === 'string' && typeof n.label === 'string')
        .map((n) => ({
          id: n.id, label: n.label, value: typeof n.value === 'string' ? n.value : '',
          aliases: Array.isArray(n.aliases) ? n.aliases.filter((x) => typeof x === 'string') : [],
          multiline: !!n.multiline, builtin: !!n.builtin
        }));
      if (!incoming.length) throw new Error('vazio');
      entries = await JF.updateEntries((es) => {
        for (const n of incoming) {
          const i = es.findIndex((x) => x.id === n.id);
          if (i >= 0) es[i] = Object.assign({}, es[i], n); else es.push(n);
        }
      });
      renderList();
      say(`${incoming.length} dados importados ✓`);
    } catch (e) { say('Arquivo inválido.'); }
    ev.target.value = '';
  };
  $('#restore').onclick = async () => {
    let added = 0;
    entries = await JF.updateEntries((es) => {
      for (const d of JF.DEFAULT_ENTRIES) {
        if (!es.some((x) => x.id === d.id)) { es.push(JSON.parse(JSON.stringify(d))); added++; }
      }
    });
    renderList();
    say(added ? `${added} dado(s) padrão restaurado(s)` : 'Nada a restaurar');
  };
})();
