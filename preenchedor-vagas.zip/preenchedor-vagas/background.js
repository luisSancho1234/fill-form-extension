// Service worker: mostra "OFF" no ícone quando desligado e trata o atalho Alt+Shift+F.

async function updateBadge() {
  const { enabled } = await chrome.storage.local.get('enabled');
  const off = enabled === false;
  await chrome.action.setBadgeText({ text: off ? 'OFF' : '' });
  await chrome.action.setBadgeBackgroundColor({ color: '#6b7280' });
}

chrome.runtime.onInstalled.addListener(updateBadge);
chrome.runtime.onStartup.addListener(updateBadge);

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.enabled) updateBadge();
});

chrome.commands.onCommand.addListener(async (cmd) => {
  if (cmd !== 'toggle-enabled') return;
  const { enabled } = await chrome.storage.local.get('enabled');
  await chrome.storage.local.set({ enabled: enabled === false });
});
