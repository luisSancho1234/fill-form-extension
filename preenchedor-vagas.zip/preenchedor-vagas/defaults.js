/* Preenchedor de Vagas — código compartilhado (content script e popup) */
(function (g) {
  'use strict';

  // Palavras ignoradas na comparação de rótulos ("Digite seu e-mail" => "email")
  const STOP = new Set(('seu sua seus suas o a os as de do da dos das digite informe insira preencha ' +
    'your enter please the obrigatorio opcional required optional campo field por favor qual quais ' +
    'e ou and or um uma no na em of to for ex exemplo').split(' '));

  function normalize(input) {
    if (input == null) return '';
    let s = String(input).slice(0, 200)
      .replace(/LinkedIn|GitHub|WhatsApp/g, (m) => m[0] + m.slice(1).toLowerCase());
    // camelCase (firstName) só em identificadores sem espaço
    if (!/\s/.test(s)) s = s.replace(/([a-z0-9])([A-Z])/g, '$1 $2');
    s = s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase()
      .replace(/e-?mail/g, 'email')
      .replace(/[^a-z0-9]+/g, ' ').trim();
    if (!s) return '';
    return s.split(' ')
      .filter((t) => t && !STOP.has(t) && !/^\d{3,}$/.test(t) && !/^[a-f0-9]{10,}$/.test(t))
      .join(' ');
  }

  const D = (id, label, aliases, extra) =>
    Object.assign({ id, label, value: '', aliases, builtin: true }, extra || {});

  // Dados padrão (sem valores): você preenche uma vez no popup ou quando a extensão perguntar.
  const DEFAULT_ENTRIES = [
    D('fullname', 'Nome completo', ['nome completo', 'nome e sobrenome', 'full name', 'name', 'nome', 'nome do candidato', 'candidate name', 'legal name', 'nome legal']),
    D('firstname', 'Primeiro nome', ['primeiro nome', 'first name', 'given name', 'firstname', 'nome proprio']),
    D('lastname', 'Sobrenome', ['sobrenome', 'ultimo nome', 'last name', 'family name', 'surname', 'lastname']),
    D('email', 'E-mail', ['email', 'email address', 'endereco de email', 'email pessoal', 'email de contato', 'contact email', 'mail']),
    D('phone', 'Telefone / celular', ['telefone', 'celular', 'whatsapp', 'fone', 'phone', 'phone number', 'mobile', 'mobile phone', 'cell phone', 'telefone celular', 'celular whatsapp', 'telefone whatsapp', 'telefone de contato', 'numero de telefone', 'tel']),
    D('cpf', 'CPF', ['cpf', 'numero do cpf', 'cpf do candidato']),
    D('rg', 'RG', ['rg', 'identidade', 'numero do rg', 'registro geral']),
    D('birth', 'Data de nascimento', ['data de nascimento', 'nascimento', 'birth date', 'date of birth', 'birthday', 'bday', 'dob', 'data nasc', 'aniversario']),
    D('cep', 'CEP', ['cep', 'codigo postal', 'postal code', 'zip code', 'zip', 'postcode']),
    D('address', 'Endereço', ['endereco', 'logradouro', 'rua', 'street address', 'address', 'address line 1', 'endereco residencial', 'endereco completo', 'street']),
    D('neighborhood', 'Bairro', ['bairro', 'neighborhood', 'district']),
    D('city', 'Cidade', ['cidade', 'city', 'municipio', 'address level2', 'town']),
    D('state', 'Estado (UF)', ['estado', 'uf', 'state', 'province', 'provincia', 'address level1', 'estado uf']),
    D('country', 'País', ['pais', 'country', 'country name']),
    D('linkedin', 'LinkedIn', ['linkedin', 'url do linkedin', 'perfil do linkedin', 'linkedin profile', 'linkedin url', 'link do linkedin']),
    D('github', 'GitHub', ['github', 'url do github', 'perfil do github', 'github profile', 'github url']),
    D('portfolio', 'Portfólio / site', ['portfolio', 'site pessoal', 'website', 'personal website', 'site', 'pagina pessoal', 'link do portfolio', 'url do portfolio', 'portfolio url', 'other website']),
    D('salary', 'Pretensão salarial', ['pretensao salarial', 'pretensao', 'salary expectation', 'salary expectations', 'expected salary', 'desired salary', 'remuneracao pretendida', 'expectativa salarial', 'salario pretendido', 'salary']),
    D('currentrole', 'Cargo atual', ['cargo atual', 'current title', 'job title', 'current position', 'current role', 'ocupacao', 'funcao atual', 'position title']),
    D('currentcompany', 'Empresa atual', ['empresa atual', 'current company', 'employer', 'empregador', 'current employer', 'ultima empresa', 'organization', 'organization name']),
    D('availability', 'Disponibilidade para início', ['disponibilidade', 'disponibilidade para inicio', 'start date', 'available start date', 'notice period', 'aviso previo', 'quando pode comecar', 'availability']),
    D('about', 'Sobre mim / carta de apresentação', ['sobre voce', 'fale sobre voce', 'about you', 'tell us about yourself', 'resumo profissional', 'professional summary', 'summary', 'carta de apresentacao', 'cover letter', 'apresentacao', 'mini bio', 'bio', 'additional information', 'informacoes adicionais'], { multiline: true }),
    D('why', 'Por que quer trabalhar aqui?', ['por que voce quer trabalhar aqui', 'por que quer trabalhar aqui', 'why do you want to work here', 'por que deseja trabalhar conosco', 'motivacao', 'motivation', 'why us', 'por que esta vaga', 'why this role', 'why are you interested'], { multiline: true })
  ];

  // Valor efetivo: Primeiro nome / Sobrenome podem ser derivados do Nome completo
  function resolveValue(entry, entries) {
    if (entry.value && String(entry.value).trim()) return String(entry.value);
    const val = (id) => {
      const x = (entries || []).find((e) => e.id === id);
      return x && x.value ? String(x.value).trim() : '';
    };
    if (entry.id === 'firstname' || entry.id === 'lastname') {
      const full = val('fullname');
      if (!full) return '';
      const parts = full.split(/\s+/);
      return entry.id === 'firstname' ? parts[0] : parts.slice(1).join(' ');
    }
    if (entry.id === 'fullname') {
      const f = val('firstname'), l = val('lastname');
      return f && l ? f + ' ' + l : '';
    }
    return '';
  }

  // ---------- Pareamento campo <-> dado salvo ----------
  function buildView(entries) {
    return entries.map((e) => Object.assign({}, e, {
      _aliases: Array.from(new Set([normalize(e.label)].concat((e.aliases || []).map(normalize)))).filter(Boolean)
    }));
  }

  function scoreSignal(sig, alias) {
    if (sig === alias) return 1;
    const st = sig.split(' '), at = alias.split(' ');
    if (at.length < st.length && (' ' + sig + ' ').indexOf(' ' + alias + ' ') !== -1) {
      return 0.9 * at.length / st.length;
    }
    return 0;
  }

  // groups: [[sinaisNormalizados, peso], ...]
  function match(groups, view) {
    let best = null;
    for (const grp of groups) {
      const sigs = grp[0], w = grp[1];
      for (const sig of sigs) {
        for (const e of view) {
          for (const a of e._aliases) {
            const sc = scoreSignal(sig, a) * w;
            if (sc > (best ? best.score : 0)) best = { entry: e, score: sc, alias: a, signal: sig };
          }
        }
      }
    }
    return best && best.score >= 0.59 ? best : null;
  }

  // ---------- Armazenamento ----------
  async function getEntries() {
    const s = await chrome.storage.local.get('entries');
    return Array.isArray(s.entries) ? s.entries : JSON.parse(JSON.stringify(DEFAULT_ENTRIES));
  }
  async function updateEntries(fn) {
    const entries = await getEntries();
    const next = fn(entries);
    const out = Array.isArray(next) ? next : entries;
    await chrome.storage.local.set({ entries: out });
    return out;
  }

  // ---------- Helper DOM (sempre textContent; nada de innerHTML) ----------
  function h(tag, props) {
    const n = document.createElement(tag);
    const kids = Array.prototype.slice.call(arguments, 2);
    for (const k of Object.keys(props || {})) {
      const v = props[k];
      if (v == null || v === false) continue;
      if (k === 'class') n.className = v;
      else if (k.indexOf('on') === 0) n.addEventListener(k.slice(2), v);
      else if (k === 'value') n.value = v;
      else if (k === 'checked' || k === 'disabled' || k === 'hidden') n[k] = !!v;
      else n.setAttribute(k, v === true ? '' : v);
    }
    for (const c of kids.flat(Infinity)) {
      if (c != null && c !== false) n.append(c.nodeType ? c : document.createTextNode(String(c)));
    }
    return n;
  }

  g.JF = { normalize, DEFAULT_ENTRIES, resolveValue, buildView, scoreSignal, match, getEntries, updateEntries, h };
})(typeof window !== 'undefined' ? window : globalThis);
