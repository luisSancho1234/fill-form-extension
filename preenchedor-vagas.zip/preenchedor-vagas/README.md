# Preenchedor de Vagas

Extensão para Chrome, Edge e Brave (Manifest V3) que detecta campos de formulários de candidatura,
**sugere** preencher com os seus dados e aprende campos novos.

## Instalar

1. Descompacte a pasta.
2. Abra `chrome://extensions` (ou `edge://extensions`).
3. Ative o **Modo do desenvolvedor**.
4. Clique em **Carregar sem compactação** e escolha a pasta `preenchedor-vagas`.
5. Fixe o ícone na barra do navegador.

## Como funciona

- Em uma página com formulário, aparece um painel no canto inferior direito.
- **Prontos para preencher**: campos reconhecidos que você já tem salvos. Desmarque o que não quiser e clique em *Preencher*.
- **Campos novos**: campos que você nunca preencheu. Escolha um dado já salvo (pareamento) ou crie um **Novo dado**,
  digite o valor e clique em *Salvar e preencher*. Na próxima vez esse campo já é reconhecido.
- Se você digitar manualmente em um campo desconhecido, o valor aparece pronto para salvar.
- No ícone da extensão você edita todos os seus dados, exporta/importa um backup (.json) e liga/desliga.

## Ligar e desligar

- Interruptor geral no popup (ícone da extensão). O ícone mostra **OFF** quando desligado.
- Interruptor **Neste site** no popup.
- Atalho **Alt+Shift+F** (muda em `chrome://extensions/shortcuts`).
- Botões *Desligar neste site* / *Desligar tudo* no próprio painel (com *Desfazer*).
- Minimizar (–) ou fechar (×) o painel só afeta a página atual.

## Privacidade

Os dados ficam em `chrome.storage.local`, no seu navegador, sem criptografia e sem envio a servidor nenhum.
A extensão ignora campos de senha, cartão e códigos de verificação.

## Limitações da versão 1

- Não preenche caixas de marcar, botões de rádio, upload de currículo nem dropdowns totalmente customizados (não-`<select>`).
- Para `<select>`, o valor salvo precisa casar com o texto de uma opção (ex.: "São Paulo").
