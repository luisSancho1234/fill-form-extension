/* Preenchedor de Vagas — content script
 * Detecta campos, pareia com seus dados salvos, SUGERE preencher e aprende campos novos. */
(() => {
  'use strict';
  const JF = window.JF;
  if (!JF || window.__jfLoaded) return;
  window.__jfLoaded = true;
  const { h, normalize } = JF;

  // Em iframes, também respeita o desligar do site "pai"
  const HOSTS = (() => {
    const l = [location.hostname];
    try { for (const o of Array.from(location.ancestorOrigins || [])) l.push(new URL(o).hostname); } catch (e) {}
    return l.filter(Boolean);
  })();

  const PH = /^\s*(-+|selecion|escolh|choose|select|\.\.\.)/i;
  const SKIP_TYPES = new Set(['hidden', 'password', 'submit', 'button', 'checkbox', 'radio', 'file', 'image', 'reset', 'search', 'color', 'range']);
  const SENSITIVE = new Set(['senha', 'password', 'cvv', 'cvc', 'card', 'cartao', 'otp', 'captcha', 'token', 'pin']);

  const state = { enabled: true, disabledSites: [], entries: [], view: [] };
  let fields = [];
  let host = null, shadow = null, panelEl = null, pillEl = null, toastEl = null;
  let dismissed = false, minimized = false, newOpen = null, lastKey = '';
  let scanTimer = null, toastTimer = null, observer = null;
  const uids = new WeakMap();
  let uidN = 0;
  const rowState = new Map(), ignored = new Set(), unchecked = new Set();

  const uid = (el) => { let u = uids.get(el); if (!u) { u = ++uidN; uids.set(el, u); } return u; };
  const isActive = () => state.enabled && !HOSTS.some((x) => state.disabledSites.includes(x));
  const bigFrame = () => window === window.top || (innerWidth >= 340 && innerHeight >= 260);
  const clip = (s, n) => (s.length > n ? s.slice(0, n - 1) + '…' : s);
  function isDead() { try { return !chrome.runtime || !chrome.runtime.id; } catch (e) { return true; } }
  function shutdown() {
    if (observer) observer.disconnect();
    clearTimeout(scanTimer);
    if (host) host.remove();
    host = null;
  }

  // ---------------------------------------------------------------- estado
  async function loadState() {
    const s = await chrome.storage.local.get(['enabled', 'disabledSites']);
    state.enabled = s.enabled !== false;
    state.disabledSites = Array.isArray(s.disabledSites) ? s.disabledSites : [];
    state.entries = await JF.getEntries();
    state.view = JF.buildView(state.entries);
  }

  // ------------------------------------------------------------- detecção
  function isVisible(el) {
    if (!el.getClientRects().length) return false;
    const cs = getComputedStyle(el);
    return cs.visibility !== 'hidden' && cs.display !== 'none' && cs.opacity !== '0';
  }

  function isCandidate(el) {
    if (el.disabled || el.readOnly) return false;
    if (el.tagName === 'INPUT') {
      if (SKIP_TYPES.has((el.type || 'text').toLowerCase())) return false;
    } else if (el.tagName !== 'TEXTAREA' && el.tagName !== 'SELECT') return false;
    if (el.closest('[role=search]')) return false;
    if (el.form && el.form.querySelector('input[type=password]')) return false; // login/cadastro
    const ac = (el.getAttribute('autocomplete') || '').toLowerCase();
    if (/(^|\s)(cc-|new-password|current-password|one-time-code)/.test(ac)) return false;
    return isVisible(el);
  }

  function ownText(node) {
    const c = node.cloneNode(true);
    c.querySelectorAll('input,select,textarea,option,script,style').forEach((n) => n.remove());
    return (c.textContent || '').replace(/\s+/g, ' ').trim();
  }

  function labelTexts(el) {
    const out = [];
    try { for (const l of (el.labels || [])) out.push(ownText(l)); } catch (e) {}
    const al = el.getAttribute('aria-label');
    if (al) out.push(al);
    const lb = el.getAttribute('aria-labelledby');
    if (lb) lb.split(/\s+/).forEach((id) => { const n = document.getElementById(id); if (n) out.push(ownText(n)); });
    if (!out.some(Boolean)) {
      let p = el.parentElement;
      for (let i = 0; i < 4 && p; i++, p = p.parentElement) {
        if (p.querySelectorAll('input:not([type=hidden]),textarea,select').length !== 1) break;
        const l = p.querySelector('label,legend');
        if (l && !l.contains(el)) { const t = ownText(l); if (t) { out.push(t); break; } }
      }
    }
    return out.filter(Boolean);
  }

  function getSignals(el) {
    const labels = labelTexts(el);
    const ph = el.getAttribute('placeholder') || '';
    const ti = el.getAttribute('title') || '';
    const primary = [...labels, ph, ti].map(normalize).filter(Boolean);
    const ac = (el.getAttribute('autocomplete') || '').toLowerCase().split(/\s+/)
      .filter((t) => t && !/^(section-|shipping|billing|home|work|mobile|fax|pager|on$|off$)/.test(t))
      .map(normalize).filter(Boolean);
    const attrs = [el.getAttribute('name') || '', el.id || ''].map(normalize).filter(Boolean);
    const type = (el.type || '').toLowerCase();
    const typeSig = type === 'email' ? ['email'] : type === 'tel' ? ['telefone'] : [];
    const groups = [[primary, 1], [ac, 1]];
    // name/id/type só entram quando o campo não tem rótulo visível (evita "Nome da empresa" virar seu nome)
    if (!primary.length) groups.push([attrs, 0.85], [typeSig, 0.7]);
    const raw = labels[0] || ph || ti || el.getAttribute('name') || el.id || '';
    return { groups, all: [...primary, ...ac, ...attrs], display: raw.slice(0, 90), key: normalize(raw).slice(0, 80) };
  }

  function hasValue(el) {
    if (el.tagName === 'SELECT') {
      const o = el.options[el.selectedIndex];
      return !!o && o.value !== '' && !PH.test(o.textContent);
    }
    return el.value.trim() !== '';
  }
  function currentText(el) {
    if (el.tagName === 'SELECT') return hasValue(el) ? el.options[el.selectedIndex].textContent.trim() : '';
    return el.value.trim();
  }

  function scan() {
    const els = Array.from(document.querySelectorAll('input,textarea,select')).filter(isCandidate);
    if (els.length <= 3 && document.querySelector('input[type=password]')) return [];
    const out = [];
    for (const el of els) {
      const sg = getSignals(el);
      if (sg.all.some((s) => s.split(' ').some((t) => SENSITIVE.has(t)))) continue;
      out.push({ el, uid: uid(el), label: sg.display, key: sg.key, match: JF.match(sg.groups, state.view) });
    }
    // Se existe "Sobrenome" na página, um "Nome" solto é o primeiro nome
    if (out.some((f) => f.match && f.match.entry.id === 'lastname')) {
      const fe = state.view.find((e) => e.id === 'firstname');
      if (fe) out.forEach((f) => {
        if (f.match && f.match.entry.id === 'fullname' && (f.match.alias === 'nome' || f.match.alias === 'name')) {
          f.match = Object.assign({}, f.match, { entry: fe });
        }
      });
    }
    return out;
  }

  function rescan() {
    if (!isActive()) { fields = []; render(true); return; }
    const found = scan();
    const matched = found.filter((f) => f.match).length;
    fields = [];
    // Só age em páginas que parecem formulário (>=3 campos, >=2 reconhecidos)
    if (found.length >= 3 && matched >= 2) {
      for (const f of found) {
        if (ignored.has(f.uid)) continue;
        const has = hasValue(f.el);
        if (f.match) {
          f.value = JF.resolveValue(f.match.entry, state.entries);
          if (f.value && has) continue; // já preenchido
          f.status = f.value ? 'ready' : 'new';
        } else f.status = 'new';
        fields.push(f);
      }
    }
    render(false);
  }

  function schedule(ms) {
    clearTimeout(scanTimer);
    scanTimer = setTimeout(() => { if (isDead()) return shutdown(); rescan(); }, ms == null ? 500 : ms);
  }

  // ------------------------------------------------------------ preencher
  function setNative(el, value) {
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype
      : el.tagName === 'SELECT' ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
    setter.call(el, value);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function flash(el) {
    const old = el.style.boxShadow;
    el.style.boxShadow = '0 0 0 3px rgba(37,99,235,.55)';
    setTimeout(() => { el.style.boxShadow = old; }, 1400);
  }

  function spot(el, on) {
    if (on) { el.__jfOutline = el.style.outline; el.style.outline = '2px dashed #2563eb'; }
    else el.style.outline = el.__jfOutline || '';
  }

  function findOption(el, value) {
    const nv = normalize(value);
    const opts = Array.from(el.options).filter((o) => o.value !== '' && !PH.test(o.textContent));
    return opts.find((o) => normalize(o.textContent) === nv || normalize(o.value) === nv) ||
      opts.find((o) => { const t = normalize(o.textContent); return nv && t.length >= 2 && (t.includes(nv) || nv.includes(t)); }) || null;
  }

  function toISODate(v) {
    if (/^\d{4}-\d{2}-\d{2}$/.test(v)) return v;
    const m = v.match(/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})$/);
    return m ? `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}` : null;
  }

  function fillField(el, value) {
    if (el.tagName === 'SELECT') {
      const o = findOption(el, value);
      if (!o) return false;
      setNative(el, o.value); flash(el); return true;
    }
    let v = value;
    const t = (el.type || '').toLowerCase();
    if (t === 'date') v = toISODate(value) || value;
    if (t === 'number') v = value.replace(/[^\d.,-]/g, '').replace(/\.(?=\d{3}(\D|$))/g, '').replace(',', '.');
    setNative(el, v); flash(el); return true;
  }

  function fillReady() {
    let ok = 0, miss = 0;
    for (const f of fields.filter((x) => x.status === 'ready' && !unchecked.has(x.uid))) {
      if (fillField(f.el, f.value)) ok++; else miss++;
    }
    toast(ok ? `✓ ${ok} campo${ok > 1 ? 's' : ''} preenchido${ok > 1 ? 's' : ''}` + (miss ? ` · ${miss} sem opção correspondente` : '')
      : 'Não encontrei opção correspondente nesses campos');
    schedule(150);
  }

  async function saveRow(f, ctrl) {
    const st = rowState.get(f.uid);
    const value = (ctrl.value || '').trim();
    if (!value) { ctrl.classList.add('err'); setTimeout(() => ctrl.classList.remove('err'), 1200); return; }
    const touched = st.value !== null;
    try {
      if (st.map === 'new') {
        const label = (st.name || f.label || f.key || '').trim() || 'Novo dado';
        const aliases = Array.from(new Set([label, f.key].filter(Boolean)));
        await JF.updateEntries((es) => {
          es.push({ id: 'u' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5), label, value, aliases, multiline: f.el.tagName === 'TEXTAREA' || value.length > 80 });
        });
      } else {
        await JF.updateEntries((es) => {
          const e = es.find((x) => x.id === st.map);
          if (!e) return;
          if (!e.value || touched) e.value = value;
          e.aliases = e.aliases || [];
          if (f.key && !e.aliases.map(normalize).includes(f.key)) e.aliases.push(f.key); // aprende o pareamento
        });
      }
    } catch (e) { toast('Não consegui salvar. Recarregue a página.'); return; }
    fillField(f.el, value);
    rowState.delete(f.uid);
    toast('✓ Salvo e preenchido');
  }

  // ------------------------------------------------------------------ UI
  const CSS = `
:host{all:initial}
*{box-sizing:border-box;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
.panel{width:340px;max-height:min(72vh,560px);flex-direction:column;background:#fff;color:#111827;border:1px solid #e5e7eb;border-radius:14px;box-shadow:0 12px 40px rgba(0,0,0,.25);font-size:13px;line-height:1.35;overflow:hidden}
.hd{display:flex;align-items:center;gap:8px;padding:10px 12px;background:#2563eb;color:#fff}
.logo{width:20px;height:20px;border-radius:50%;background:#fff;color:#2563eb;display:grid;place-items:center;font-weight:700;font-size:12px}
.ttl{flex:1;font-weight:600}
.ib{all:unset;cursor:pointer;width:22px;height:22px;text-align:center;border-radius:6px;font-size:16px;line-height:22px}
.ib:hover{background:rgba(255,255,255,.2)}
.body{padding:10px 12px;overflow:auto;display:flex;flex-direction:column;gap:8px}
.sec{font-size:11px;text-transform:uppercase;letter-spacing:.04em;color:#6b7280;font-weight:600}
button.tog{all:unset;cursor:pointer;font-size:11px;text-transform:uppercase;letter-spacing:.04em;color:#6b7280;font-weight:600;margin-top:6px}
.row{display:flex;gap:8px;align-items:flex-start;padding:6px 8px;border:1px solid #e5e7eb;border-radius:8px}
.row.ready{cursor:pointer}
.row.ready:hover{background:#f3f4f6}
.row.new{flex-direction:column;align-items:stretch;gap:6px;background:#f9fafb}
.col{display:flex;flex-direction:column;min-width:0}
.lbl{font-weight:600;overflow:hidden;text-overflow:ellipsis}
.val{color:#4b5563;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.txt{width:100%;padding:6px 8px;border:1px solid #d1d5db;border-radius:6px;background:#fff;color:#111827;font-size:13px}
.txt.err{border-color:#dc2626;box-shadow:0 0 0 2px rgba(220,38,38,.2)}
.acts{display:flex;gap:6px}
.btn{cursor:pointer;border:1px solid #d1d5db;background:#fff;color:#111827;border-radius:8px;padding:7px 10px;font-size:13px}
.btn.primary{background:#2563eb;border-color:#2563eb;color:#fff;font-weight:600}
.btn.sm{padding:5px 9px;font-size:12px}
.btn.full{width:100%}
.btn:disabled{opacity:.5;cursor:not-allowed}
.ft{display:flex;gap:8px;justify-content:center;padding:8px;border-top:1px solid #e5e7eb;color:#9ca3af;font-size:12px}
.link{all:unset;cursor:pointer;color:#2563eb;text-decoration:underline;font-size:12px}
.pill{all:unset;cursor:pointer;background:#2563eb;color:#fff;border-radius:999px;padding:9px 14px;font:600 13px system-ui,sans-serif;box-shadow:0 8px 24px rgba(0,0,0,.25)}
.toast{align-items:center;gap:10px;background:#111827;color:#fff;border-radius:10px;padding:9px 12px;font-size:13px;box-shadow:0 8px 24px rgba(0,0,0,.3)}
.toast .link{color:#93c5fd}
@media (prefers-color-scheme:dark){
.panel{background:#111827;color:#f3f4f6;border-color:#374151}
.row{border-color:#374151}.row.ready:hover{background:#1f2937}.row.new{background:#0f172a}
.txt{background:#1f2937;color:#f3f4f6;border-color:#4b5563}
.btn{background:#1f2937;color:#f3f4f6;border-color:#4b5563}
.btn.primary{background:#2563eb;border-color:#2563eb;color:#fff}
.val{color:#9ca3af}.ft{border-color:#374151}}`;

  function ensureHost() {
    if (host && host.isConnected) return;
    host = document.createElement('div');
    host.id = 'jobfill-ext-host';
    host.style.cssText = 'all:initial;position:fixed;right:16px;bottom:16px;z-index:2147483647;display:flex;flex-direction:column;align-items:flex-end;gap:8px;';
    shadow = host.attachShadow({ mode: 'open' });
    const style = document.createElement('style');
    style.textContent = CSS;
    panelEl = h('div', { class: 'panel' });
    pillEl = h('button', { class: 'pill', onclick: () => { minimized = false; render(true); } });
    toastEl = h('div', { class: 'toast' });
    panelEl.style.display = 'none'; pillEl.style.display = 'none'; toastEl.style.display = 'none';
    shadow.append(style, panelEl, pillEl, toastEl);
    document.documentElement.appendChild(host);
  }

  function syncHost() {
    if (!host) return;
    if (![panelEl, pillEl, toastEl].some((n) => n.style.display !== 'none')) { host.remove(); host = null; shadow = null; }
  }

  function toast(msg, label, action) {
    ensureHost();
    toastEl.replaceChildren(h('span', {}, msg), label ? h('button', { class: 'link', onclick: () => { hideToast(); action(); } }, label) : null);
    toastEl.style.display = 'flex';
    clearTimeout(toastTimer);
    toastTimer = setTimeout(hideToast, label ? 8000 : 2600);
  }
  function hideToast() { if (toastEl) toastEl.style.display = 'none'; clearTimeout(toastTimer); syncHost(); }

  async function setSite(site, off) {
    const s = await chrome.storage.local.get('disabledSites');
    const l = (Array.isArray(s.disabledSites) ? s.disabledSites : []).filter((x) => x !== site);
    if (off) l.push(site);
    await chrome.storage.local.set({ disabledSites: l });
  }
  async function turnOffSite() {
    const site = location.hostname;
    toast('Desligado em ' + site + '. Reative pelo ícone da extensão.', 'Desfazer', () => setSite(site, false));
    await setSite(site, true);
  }
  async function turnOffAll() {
    toast('Preenchedor desligado (Alt+Shift+F liga de novo).', 'Desfazer', () => chrome.storage.local.set({ enabled: true }));
    await chrome.storage.local.set({ enabled: false });
  }

  function valueControl(f, val, onInput) {
    const onIn = (e) => onInput(e.target.value);
    if (f.el.tagName === 'SELECT') {
      const texts = Array.from(new Set(Array.from(f.el.options).filter((o) => o.value !== '' && !PH.test(o.textContent)).map((o) => o.textContent.trim())));
      const s = h('select', { class: 'txt', onchange: onIn }, h('option', { value: '' }, 'Escolha o valor…'), texts.map((t) => h('option', { value: t }, t)));
      const o = val ? findOption(f.el, val) : null;
      s.value = o ? o.textContent.trim() : '';
      return s;
    }
    if (f.el.tagName === 'TEXTAREA') return h('textarea', { class: 'txt', rows: 3, placeholder: 'Valor', value: val, oninput: onIn });
    return h('input', { class: 'txt', type: 'text', placeholder: 'Valor', value: val, oninput: onIn });
  }

  function readyRow(f) {
    const cb = h('input', {
      type: 'checkbox', checked: !unchecked.has(f.uid),
      onchange: (e) => { if (e.target.checked) unchecked.delete(f.uid); else unchecked.add(f.uid); render(true); }
    });
    return h('label', { class: 'row ready', onmouseenter: () => spot(f.el, true), onmouseleave: () => spot(f.el, false) },
      cb,
      h('span', { class: 'col' },
        h('span', { class: 'lbl' }, f.label || f.match.entry.label),
        h('span', { class: 'val' }, '→ ' + clip(f.value, 48))));
  }

  function newRow(f) {
    let st = rowState.get(f.uid);
    if (!st) { st = { map: f.match ? f.match.entry.id : 'new', name: f.label, value: null }; rowState.set(f.uid, st); }
    if (st.map !== 'new' && !state.view.some((e) => e.id === st.map)) st.map = 'new';
    const entry = st.map === 'new' ? null : state.view.find((e) => e.id === st.map);
    const cur = currentText(f.el);
    const val = st.value !== null ? st.value : (entry ? (JF.resolveValue(entry, state.entries) || cur) : cur);
    const mapSel = h('select', { class: 'txt', onchange: (e) => { st.map = e.target.value; st.value = null; render(true); } },
      h('option', { value: 'new' }, '➕ Novo dado'),
      state.view.map((en) => h('option', { value: en.id }, en.label)));
    mapSel.value = st.map;
    const ctrl = valueControl(f, val, (v) => { st.value = v; });
    return h('div', { class: 'row new', onmouseenter: () => spot(f.el, true), onmouseleave: () => spot(f.el, false) },
      h('div', { class: 'lbl' }, f.label || '(campo sem rótulo)'),
      mapSel,
      st.map === 'new' ? h('input', { class: 'txt', type: 'text', placeholder: 'Nome deste dado (ex.: Pretensão salarial)', value: st.name, oninput: (e) => { st.name = e.target.value; } }) : null,
      ctrl,
      h('div', { class: 'acts' },
        h('button', { class: 'btn primary sm', onclick: () => saveRow(f, ctrl) }, 'Salvar e preencher'),
        h('button', { class: 'btn sm', onclick: () => { ignored.add(f.uid); rescan(); } }, 'Ignorar')));
  }

  function render(force) {
    const show = isActive() && !dismissed && fields.length > 0 && bigFrame();
    if (!show) {
      lastKey = '';
      if (host) { panelEl.style.display = 'none'; pillEl.style.display = 'none'; syncHost(); }
      return;
    }
    const ready = fields.filter((f) => f.status === 'ready');
    const news = fields.filter((f) => f.status === 'new');
    ensureHost();
    const key = JSON.stringify([minimized, newOpen,
      ready.map((f) => [f.uid, f.match.entry.id, f.value]),
      news.map((f) => [f.uid, f.match ? f.match.entry.id : '', currentText(f.el)])]);
    const a = shadow.activeElement;
    if (!force && (key === lastKey || (a && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName)))) return;
    lastKey = key;

    if (minimized) {
      pillEl.textContent = `✎ Preencher (${ready.length + news.length})`;
      pillEl.style.display = 'block';
      panelEl.style.display = 'none';
      return;
    }

    const oldBody = panelEl.querySelector('.body');
    const scroll = oldBody ? oldBody.scrollTop : 0;
    const hd = h('div', { class: 'hd' },
      h('span', { class: 'logo' }, '✓'),
      h('span', { class: 'ttl' }, 'Preenchedor de Vagas'),
      h('button', { class: 'ib', title: 'Minimizar', onclick: () => { minimized = true; render(true); } }, '–'),
      h('button', { class: 'ib', title: 'Fechar nesta página', onclick: () => { dismissed = true; render(true); } }, '×'));
    const body = h('div', { class: 'body' });
    if (ready.length) {
      body.append(h('div', { class: 'sec' }, 'Prontos para preencher'));
      ready.forEach((f) => body.append(readyRow(f)));
      const n = ready.filter((f) => !unchecked.has(f.uid)).length;
      body.append(h('button', { class: 'btn primary full', disabled: n === 0, onclick: fillReady }, `Preencher ${n} campo${n === 1 ? '' : 's'}`));
    }
    if (news.length) {
      const open = newOpen === null ? news.length <= 4 : newOpen;
      body.append(h('button', { class: 'tog', onclick: () => { newOpen = !open; render(true); } },
        `${open ? '▾' : '▸'} Campos novos (${news.length}) — me diga o valor`));
      if (open) news.forEach((f) => body.append(newRow(f)));
    }
    const ft = h('div', { class: 'ft' },
      h('button', { class: 'link', onclick: turnOffSite }, 'Desligar neste site'),
      h('span', {}, '·'),
      h('button', { class: 'link', onclick: turnOffAll }, 'Desligar tudo'));
    panelEl.replaceChildren(hd, body, ft);
    body.scrollTop = scroll;
    panelEl.style.display = 'flex';
    pillEl.style.display = 'none';
  }

  // ----------------------------------------------------------------- init
  try {
    chrome.storage.onChanged.addListener((ch, area) => {
      if (area !== 'local' || isDead()) return;
      if (ch.enabled || ch.disabledSites || ch.entries) {
        loadState().then(() => { lastKey = ''; rescan(); }).catch(() => {});
      }
    });
  } catch (e) {}

  loadState().then(() => {
    rescan();
    observer = new MutationObserver((muts) => {
      if (host && muts.every((m) => host.contains(m.target))) return;
      schedule(600);
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
    document.addEventListener('change', () => schedule(300), true);
    document.addEventListener('focusout', () => schedule(300), true);
    window.addEventListener('load', () => schedule(600));
  }).catch(() => {});
})();
